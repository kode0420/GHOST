<#
================================================================================
  KODE420 GHOST v1.0
  Privacidad y Debloat para Windows 10

  Elimina apps preinstaladas innecesarias (bloatware), bloquea telemetria,
  publicidad personalizada, historial de actividad, ubicacion y sugerencias
  del sistema. Crea un punto de restauracion antes de tocar nada.

  Complementa a KODE420 PURGE: PURGE libera RAM/cache al momento y se puede
  correr a diario. GHOST elimina bloatware y telemetria de forma permanente,
  se corre UNA sola vez.

  Requiere: Windows 10 (build 1809+), PowerShell 5.1+, permisos de Administrador.
  Uso: doble clic en KODE420-GHOST.bat.

  Nota: los mensajes evitan tildes/ene a proposito para prevenir problemas
  de codificacion en consolas de Windows con distinto codepage.
================================================================================
#>

# ------------------------------------------------------------------------------
# 0. AUTO-ELEVACION
# ------------------------------------------------------------------------------
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

$ErrorActionPreference = 'SilentlyContinue'
$ScriptRoot = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$ReportPath = Join-Path $ScriptRoot ("KODE420-GHOST-Report-{0}.txt" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$Report = New-Object System.Collections.Generic.List[string]
$sw = [System.Diagnostics.Stopwatch]::StartNew()

# ------------------------------------------------------------------------------
# 1. HELPERS DE SALIDA (mismo estilo que PURGE)
# ------------------------------------------------------------------------------
function Log($msg) { $Report.Add($msg) | Out-Null }
function Write-Sep  { Write-Host ('=' * 70) -ForegroundColor DarkGray }
function Write-Ok   ($m) { Write-Host "  [OK] $m" -ForegroundColor Green;  Log "[OK] $m" }
function Write-Info ($m) { Write-Host "  [i]  $m" -ForegroundColor Cyan;   Log "[INFO] $m" }
function Write-Warn ($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow; Log "[WARN] $m" }
function Write-Title($m) { Write-Host ""; Write-Sep; Write-Host " $m" -ForegroundColor Magenta; Write-Sep; Log "== $m ==" }

# ------------------------------------------------------------------------------
# 2. CONFIGURACION (editable)
# ------------------------------------------------------------------------------
# Apps preinstaladas a eliminar. Nombre exacto del paquete o patron con * al
# final. Si usas alguna de estas de verdad, borra o comenta esa linea (con #).
$BloatApps = @(
    'Microsoft.3DBuilder'
    'Microsoft.BingFinance'
    'Microsoft.BingNews'
    'Microsoft.BingSports'
    'Microsoft.BingWeather'
    'Microsoft.GetHelp'
    'Microsoft.Getstarted'
    'Microsoft.Messaging'
    'Microsoft.Microsoft3DViewer'
    'Microsoft.MicrosoftOfficeHub'
    'Microsoft.MicrosoftSolitaireCollection'
    'Microsoft.MixedReality.Portal'
    'Microsoft.NetworkSpeedTest'
    'Microsoft.News'
    'Microsoft.Office.Lens'
    'Microsoft.Office.Sway'
    'Microsoft.Office.Todo.List'
    'Microsoft.OneConnect'
    'Microsoft.People'
    'Microsoft.Print3D'
    'Microsoft.SkypeApp'
    'Microsoft.Wallet'
    'Microsoft.WindowsAlarms'
    'Microsoft.WindowsFeedbackHub'
    'Microsoft.WindowsMaps'
    'Microsoft.WindowsSoundRecorder'
    'Microsoft.Xbox.TCUI'
    'Microsoft.XboxApp'
    'Microsoft.XboxGameOverlay'
    'Microsoft.XboxGamingOverlay'
    'Microsoft.XboxIdentityProvider'
    'Microsoft.XboxSpeechToTextOverlay'
    'Microsoft.YourPhone'
    'Microsoft.ZuneMusic'
    'Microsoft.ZuneVideo'
    'Microsoft.Todos'
    'Microsoft.PowerAutomateDesktop'
    'Microsoft.OutlookForWindows'
    'Clipchamp.Clipchamp'
    'SpotifyAB.SpotifyMusic'
    'king.com.*'
    'Facebook.*'
    'Disney.*'
)
# NUNCA agregues aqui: Calculator, Camera, Photos, Store, Notepad, Paint,
# ScreenSketch, VCLibs, NET.Native, UI.Xaml, DesktopAppInstaller.
# Son parte del sistema o utilidades reales; borrarlas puede romper Windows.

$RestorePointEnabled = $true

# ------------------------------------------------------------------------------
# 3. HELPERS DE ESTADO
# ------------------------------------------------------------------------------
function Get-AppCount { (Get-AppxPackage -AllUsers | Measure-Object).Count }

# ------------------------------------------------------------------------------
# 4. EJECUCION
# ------------------------------------------------------------------------------
Clear-Host
Write-Title "KODE420 GHOST v1.0 - Privacidad y Debloat Windows 10"
Write-Info "Inicio: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
Write-Info "Este script se ejecuta UNA vez. No hace falta repetirlo cada dia como PURGE."

Write-Title "1/6 - Punto de restauracion de seguridad"
if ($RestorePointEnabled) {
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "SystemRestorePointCreationFrequency" -Value 0 -Type DWord -ErrorAction SilentlyContinue
        Checkpoint-Computer -Description "KODE420 GHOST - Antes de aplicar cambios" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
        Write-Ok "Punto de restauracion creado - puedes deshacer todo desde Recuperacion si algo no te gusta"
    } catch {
        Write-Warn "No se pudo crear el punto de restauracion (puede estar deshabilitado en este equipo). Continuando de todas formas."
    }
} else {
    Write-Info "Punto de restauracion desactivado en configuracion"
}

Write-Title "2/6 - Analizando estado actual"
$appsBefore = Get-AppCount
Write-Info "Apps instaladas actualmente (sistema + usuario): $appsBefore"

Write-Title "3/6 - Eliminando bloatware preinstalado"
$removedApps = New-Object System.Collections.Generic.List[string]
foreach ($pattern in $BloatApps) {
    $pkgs = Get-AppxPackage -AllUsers -Name $pattern -ErrorAction SilentlyContinue
    foreach ($pkg in $pkgs) {
        try {
            Remove-AppxPackage -Package $pkg.PackageFullName -AllUsers -ErrorAction Stop
            $removedApps.Add($pkg.Name) | Out-Null
            Write-Ok "Eliminado: $($pkg.Name)"
        } catch {}
    }
    $prov = Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like $pattern }
    foreach ($p in $prov) {
        try { Remove-AppxProvisionedPackage -Online -PackageName $p.PackageName -ErrorAction Stop | Out-Null } catch {}
    }
}
if ($removedApps.Count -eq 0) {
    Write-Info "Ninguna app de la lista estaba instalada (o ya la habias quitado antes)"
} else {
    Write-Ok "Total de apps eliminadas: $($removedApps.Count)"
}

Write-Title "4/6 - Bloqueando telemetria"
Stop-Service "DiagTrack" -Force -ErrorAction SilentlyContinue
Set-Service "DiagTrack" -StartupType Disabled -ErrorAction SilentlyContinue
Write-Ok "Servicio de telemetria (DiagTrack) desactivado"

Stop-Service "dmwappushservice" -Force -ErrorAction SilentlyContinue
Set-Service "dmwappushservice" -StartupType Disabled -ErrorAction SilentlyContinue
Write-Ok "Servicio de mensajes push WAP desactivado"

New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection" -Name "AllowTelemetry" -Value 0 -Type DWord
Write-Ok "Nivel de telemetria del sistema puesto en minimo"

$scheduledTasks = @(
    @{ Path = '\Microsoft\Windows\Application Experience\'; Name = 'Microsoft Compatibility Appraiser' }
    @{ Path = '\Microsoft\Windows\Application Experience\'; Name = 'ProgramDataUpdater' }
    @{ Path = '\Microsoft\Windows\Autochk\';                Name = 'Proxy' }
    @{ Path = '\Microsoft\Windows\Customer Experience Improvement Program\'; Name = 'Consolidator' }
    @{ Path = '\Microsoft\Windows\Customer Experience Improvement Program\'; Name = 'KernelCeipTask' }
    @{ Path = '\Microsoft\Windows\Customer Experience Improvement Program\'; Name = 'UsbCeip' }
    @{ Path = '\Microsoft\Windows\DiskDiagnostic\';          Name = 'Microsoft-Windows-DiskDiagnosticDataCollector' }
    @{ Path = '\Microsoft\Windows\Feedback\Siuf\';           Name = 'DmClient' }
    @{ Path = '\Microsoft\Windows\Feedback\Siuf\';           Name = 'DmClientOnScenarioDownload' }
    @{ Path = '\Microsoft\Windows\Windows Error Reporting\'; Name = 'QueueReporting' }
)
$tasksOff = 0
foreach ($t in $scheduledTasks) {
    try {
        Disable-ScheduledTask -TaskPath $t.Path -TaskName $t.Name -ErrorAction Stop | Out-Null
        $tasksOff++
    } catch {}
}
Write-Ok "Tareas programadas de recoleccion de datos desactivadas: $tasksOff de $($scheduledTasks.Count)"

Write-Title "5/6 - Endureciendo privacidad"
New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" -Name "Enabled" -Value 0 -Type DWord
Write-Ok "ID de publicidad desactivado"

New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy" -Name "TailoredExperiencesWithDiagnosticDataEnabled" -Value 0 -Type DWord
Write-Ok "Experiencias personalizadas con datos de diagnostico desactivadas"

New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "EnableActivityFeed" -Value 0 -Type DWord
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "PublishUserActivities" -Value 0 -Type DWord
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System" -Name "UploadUserActivities" -Value 0 -Type DWord
Write-Ok "Historial de actividad (Timeline) desactivado"

Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration" -Name "Status" -Value 0 -Type DWord -ErrorAction SilentlyContinue
Write-Ok "Rastreo de ubicacion desactivado"

New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search" -Name "BingSearchEnabled" -Value 0 -Type DWord
New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search" -Name "AllowCortana" -Value 0 -Type DWord
Write-Ok "Busqueda de Bing y Cortana desactivadas en el menu inicio"

$cdm = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
New-Item -Path $cdm -Force | Out-Null
$cdmProps = @(
    'SubscribedContent-338388Enabled'
    'SilentInstalledAppsEnabled'
    'SystemPaneSuggestionsEnabled'
    'PreInstalledAppsEnabled'
    'OemPreInstalledAppsEnabled'
    'RotatingLockScreenEnabled'
    'RotatingLockScreenOverlayEnabled'
    'SoftLandingEnabled'
    'ContentDeliveryAllowed'
)
foreach ($p in $cdmProps) { Set-ItemProperty -Path $cdm -Name $p -Value 0 -Type DWord -ErrorAction SilentlyContinue }
Write-Ok "Anuncios y sugerencias del menu inicio / pantalla de bloqueo desactivados"

New-Item -Path "HKCU:\Software\Microsoft\Siuf\Rules" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Siuf\Rules" -Name "NumberOfSIUFInPeriod" -Value 0 -Type DWord
Write-Ok "Frecuencia de encuestas de feedback puesta en cero"

Write-Title "6/6 - Resultado final"
Start-Sleep -Milliseconds 500
$appsAfter = Get-AppCount
$sw.Stop()

Write-Host ""
Write-Host "  Apps antes .......... $appsBefore" -ForegroundColor White
Write-Host "  Apps despues ........ $appsAfter" -ForegroundColor White
Write-Host "  Apps eliminadas ..... $($removedApps.Count)" -ForegroundColor Green
Write-Host "  Tareas de telemetria desactivadas: $tasksOff de $($scheduledTasks.Count)" -ForegroundColor Green
Write-Host "  Protecciones de privacidad aplicadas: 8 categorias" -ForegroundColor Green
Write-Host "  Tiempo total: $([math]::Round($sw.Elapsed.TotalSeconds,1)) s" -ForegroundColor White
Write-Sep

Log "Apps antes: $appsBefore | Apps despues: $appsAfter | Eliminadas: $($removedApps.Count)"
Log "Tareas de telemetria desactivadas: $tasksOff/$($scheduledTasks.Count)"
$Report | Out-File -FilePath $ReportPath -Encoding UTF8
Write-Info "Reporte guardado en: $ReportPath"
Write-Host ""
